import React from 'react';

const donorsData = [
  { name: 'YOUSAF SHAKOOR', bloodGroup: 'O+', lastDonationDate: '2023-10-15' },
  { name: 'Adeem Inam', bloodGroup: 'A+', lastDonationDate: '2023-09-21' }
];

function DonorHistory() {
  return (
    <section id="donor-history-section">
      <h2>Donor History</h2>
      <div id="donor-history">
        {donorsData.map((donor, index) => (
          <div key={index} className="donor-card">
            <p><strong>Name:</strong> {donor.name}</p>
            <p><strong>Blood Group:</strong> {donor.bloodGroup}</p>
            <p><strong>Last Donation Date:</strong> {donor.lastDonationDate}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export default DonorHistory;
