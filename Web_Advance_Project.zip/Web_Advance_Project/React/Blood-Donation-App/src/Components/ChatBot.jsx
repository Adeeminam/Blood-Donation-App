import React, { useState } from 'react';

function ChatBot() {
  const [messages, setMessages] = useState([]);

  const sendMessage = () => {
    const input = document.getElementById('chat-input').value.trim();
    if (input) {
      const userMessage = { sender: 'User', message: input };
      const botMessage = processChatResponse(input);
      setMessages([...messages, userMessage, botMessage]);
    }
    document.getElementById('chat-input').value = '';
  };

  const processChatResponse = (input) => {
    let response = '';
    if (input.toLowerCase().includes('hello')) {
      response = 'Hello! How can I assist you today?';
    } else if (input.toLowerCase().includes('blood donation')) {
      response = 'You can donate blood by signing up or finding a nearby donor.';
    } else {
      response = 'Sorry, I didn\'t understand that.';
    }
    return { sender: 'Bot', message: response };
  };

  return (
    <section id="chatbot-section">
      <h2>Chat with Us</h2>
      <div id="chatbot-container">
        <div id="chat-window">
          {messages.map((msg, index) => (
            <div key={index} className={msg.sender === 'User' ? 'user-message' : 'bot-message'}>
              {msg.sender}: {msg.message}
            </div>
          ))}
        </div>
        <div id="chat-input-container">
          <input type="text" id="chat-input" placeholder="Ask a question..." />
          <button onClick={sendMessage} id="send-btn">Send</button>
        </div>
      </div>
    </section>
  );
}

export default ChatBot;
