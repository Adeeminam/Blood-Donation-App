import React from 'react';

function Footer() {
  return (
    <footer>
      <p>&copy; 2025 Blood Donation App. All Rights Reserved.</p>
    </footer>
  );
}

export default Footer;
