import React, { useState } from 'react';

const donorsData = [
  { name: 'Yousaf Shakoor', bloodGroup: 'O+', distance: '2 km', available: true, contact: '03047043322' },
  { name: 'Adeem Inam', bloodGroup: 'A+', distance: '3.5 km', available: false, contact: '03047043322' },
  { name: 'Junaid Iyas', bloodGroup: 'B+', distance: '1.5 km', available: true, contact: '03047043322' },
  { name: 'Shehram Ali', bloodGroup: 'AB-', distance: '5 km', available: true, contact: '03047043322' }
];

function LocationSection() {
  const [filteredDonors, setFilteredDonors] = useState([]);

  const filterDonors = () => {
    const bloodTypeFilter = document.getElementById('blood-type-filter').value;
    const availabilityFilter = document.getElementById('availability-filter').value;

    const results = donorsData.filter(donor => {
      return (bloodTypeFilter === '' || donor.bloodGroup === bloodTypeFilter) &&
        (availabilityFilter === '' || (availabilityFilter === 'Available' && donor.available) ||
          (availabilityFilter === 'Not Available' && !donor.available));
    });

    setFilteredDonors(results);
  };

  const getUserLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
        const { latitude, longitude } = position.coords;
        console.log(`Latitude: ${latitude}, Longitude: ${longitude}`);
        alert('Location detected! You can now search for nearby donors.');
      }, () => {
        alert('Unable to retrieve your location.');
      });
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  };

  return (
    <section id="location-section">
      <h2>Find Nearby Blood Donors</h2>
      <div className="filter-section">
        <button onClick={getUserLocation} id="use-location-btn">Use My Location</button>
        <select id="blood-type-filter">
          <option value="">All Blood Types</option>
          <option value="A+">A+</option>
          <option value="A-">A-</option>
          <option value="B+">B+</option>
          <option value="B-">B-</option>
          <option value="O+">O+</option>
          <option value="O-">O-</option>
          <option value="AB+">AB+</option>
          <option value="AB-">AB-</option>
        </select>
        <select id="availability-filter">
          <option value="">All Availability</option>
          <option value="Available">Available</option>
          <option value="Not Available">Not Available</option>
        </select>
        <button onClick={filterDonors} id="filter-btn">Filter Donors</button>
      </div>
      <div id="donor-results">
        {filteredDonors.length > 0 ? (
          filteredDonors.map((donor, index) => (
            <div key={index} className="donor-card">
              <p><strong>Name:</strong> {donor.name}</p>
              <p><strong>Blood Group:</strong> {donor.bloodGroup}</p>
              <p><strong>Distance:</strong> {donor.distance}</p>
              <p><strong>Availability:</strong> {donor.available ? 'Available' : 'Not Available'}</p>
              <button onClick={() => alert(`Contacting donor at: ${donor.contact}`)}>Contact Donor</button>
            </div>
          ))
        ) : (
          <p>No donors match your search criteria.</p>
        )}
      </div>
    </section>
  );
}

export default LocationSection;
