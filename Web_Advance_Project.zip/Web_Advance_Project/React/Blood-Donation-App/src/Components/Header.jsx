import React from 'react';

function Header() {
  return (
    <header>
      <h1>Blood Donation App</h1>
      <p>Connecting donors and recipients quickly in emergencies.</p>
    </header>
  );
}

export default Header;
